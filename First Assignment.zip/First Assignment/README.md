# Cucumber/Selenium sample of automated tests

Suite of automated tests of the Twitter site using Cucumber, Selenium and Java.

Developed features:
+ Login
+ Add Tweet
+ Delete Tweet

To be developed features:

+ Pin Tweet
+ Change photo
+ Follow another user

Open to reviews and suggestions on l.fvm23@gmail.com