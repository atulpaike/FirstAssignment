Package stepD;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
public class FetcheDetails{
WebDriver driver;
@Given("^Given User is on twitter frontpage$")
public void User_is_on_twitter_frontpage() throws Throwable {
        driver = new FirefoxDriver();
        String actualUrl="https://twitter.com/home";
        String expectedUrl= driver.getCurrentUrl();
        Assert.assertEquals(expectedUrl,actualUrl);
        driver.findElement(By.xpath("//div[@class="css-1dbjc4n r-18u37iz r-13qz1uu r-417010"]).click
}
 
@When("^User fetches BIO field details $")
public void User_Fetches_Bio_field_details() throws Throwable {
String Bio = driver.findElement(By.xpath("//div[@Span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0"]).gettext();
assertEquals(Bio,"Selenium Automation user");
if(Bio.equals("Selenium Automation user")) {
    System.out.println("Bio is:"+Bio);
} else {
    System.out.println("Bio not found");
}
}
@And("^User fetches Location field details $")
public void User_Fetches_Location_field_details() throws Throwable {
String Location = driver.findElement(By.xpath("//div[@Span class="css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0"]).gettext();
assertEquals(Location,"Selenium Automation user");
if(Location.equals("Pune")) {
    System.out.println("Location is:"+Location);
} else {
    System.out.println("Location not found");
}
}
@And("^User fetches Website field details $")
public void User_Fetches_Website_field_details() throws Throwable {
String Location = driver.findElement(By.xpath("//div[@class="r-1re7ezh r-4qtqp9 r-yyyyoo r-1xvli5t r-7o8qx1 r-dnmrzs r-bnwqim r-1plcrui r-lrvibr"]).gettext();
assertEquals(Website,"Selenium Automation user");
if(Website.equals("tweeter.com")) {
    System.out.println("Website is:"+Website);
} else {
    System.out.println("Website not found");
}
}
}
