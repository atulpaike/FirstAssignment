Package stepD;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
public class UpdateWebsite{
WebDriver driver;
@Given("^Given User is on twitter frontpage$")
public void User_is_on_twitter_frontpage() throws Throwable {
        driver = new FirefoxDriver();
        String actualUrl="https://twitter.com/home";
        String expectedUrl= driver.getCurrentUrl();
        Assert.assertEquals(expectedUrl,actualUrl);
        driver.findElement(By.xpath("//div[@class="css-1dbjc4n r-18u37iz r-13qz1uu r-417010"]).click
}
 
@And("^User clicks Edit Profile$")
public void User_clicks_Edit_Profile() throws Throwable {
driver.findElement(By.xpath("//div[@Span class="css-911oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0"]).click
}
@And("^User enters Website with twitter.com$")
public void User_enters_Website() throws Throwable {
driver.findElement(By.xpath("//input[@placeholder='Add your website']")).sendKeys("twitter.com");
}

@And("^User clicks Save button$")
public void User_clicks__Save_button() throws Throwable {
driver.findElement(By.cssSelector("div[class='Savebtnsec'] > button[type='Profile_Save_Button']")).click();
}

}
